package com.newpackage.neetcounsel.service;


import java.util.Map;

import com.newpackage.neetcounsel.dtos.PaymentDTO;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(
name="payment-service",url = "http://localhost:8090/payment"
)
public interface PaymentClient {

    @GetMapping("/get-key")
    ResponseEntity<Map<String, String>> getKey();

    @PostMapping("/order")
    String createOrder();

    @PostMapping("/verify")
    boolean verify(@RequestBody PaymentDTO paymentDTO);
}
